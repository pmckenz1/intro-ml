# [SimPhy: A comprehensive simulator of gene family evolution](https://github.com/adamallo/SimPhy)
Diego Mallo, Leonardo de Oliveira Martins and  David Posada (2015)

Installation
------------
Please see the manual distributed with this file or the wiki at [https://github.com/adamallo/SimPhy/wiki](https://github.com/adamallo/SimPhy/wiki).

Bug report and questions
------------------------
You can contact other users and developers at [https://groups.google.com/forum/#!forum/simphy](https://groups.google.com/forum/#!forum/simphy).
